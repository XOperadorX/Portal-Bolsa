(function() {
    'use strict';

    // ============================================================
    // CONFIGURAÇÕES SUPABASE
    // ============================================================
    const SUPABASE_URL = 'https://xrcxvizzdumcxbylmkvn.supabase.co';
    const SUPABASE_KEY = 'sb_publishable_E-g3G3wW4EySbCsXLXp8KQ_FnmERMcD';
    const TABELA = 'Geral';

    const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

    // ============================================================
    // REFERÊNCIAS DOS ELEMENTOS
    // ============================================================
    const userNickEl = document.getElementById('userNick');
    const userBalanceEl = document.getElementById('userBalance');
    const userAvatarEl = document.getElementById('userAvatar');
    const headerUserEl = document.getElementById('headerUser');
    const logList = document.getElementById('logList');
    const loadingOverlay = document.getElementById('gameLoadingOverlay');
    const loadingIcon = document.getElementById('loadingIcon');
    const loadingTitle = document.getElementById('loadingTitle');
    const loadingSub = document.getElementById('loadingSub');
    const loadingStamina = document.getElementById('loadingStamina');
    const loadingProgressFill = document.getElementById('loadingProgressFill');

    // ============================================================
    // ESTADO DO NÍVEL
    // ============================================================
    const levelState = {
        nivel: 1,
        exp: 0,
        hp: 100,
        mp: 50,
        sm: 100,
        hpMax: 100,
        mpMax: 50,
        smMax: 40,
        atkBase: 15,
        defBase: 10,
        magBase: 8,
        usuario: null,
        supabaseOnline: false,
        supabase: supabase,
        usuarioLogado: null,
        ultimaAtividade: null,
        atividades: [],
        totalTreinos: 0,
        totalDescansos: 0,
        ultimoReset: null,
        gameCards: null
    };

    // ============================================================
    // FUNÇÕES DE CÁLCULO DO NÍVEL
    // ============================================================
    function getExpProx() {
        return Math.floor(100 * Math.pow(1.2, levelState.nivel - 1));
    }

    function getHpMax() {
        return levelState.hpMax + Math.floor(levelState.nivel * 6);
    }

    function getMpMax() {
        return levelState.mpMax + Math.floor(levelState.nivel * 4);
    }

    function getSmMax() {
        return levelState.smMax + Math.floor(levelState.nivel * 3);
    }

    function getAtk() {
        return levelState.atkBase + Math.floor(levelState.nivel * 1.5);
    }

    function getDef() {
        return levelState.defBase + Math.floor(levelState.nivel * 1.2);
    }

    function getMag() {
        return levelState.magBase + Math.floor(levelState.nivel * 1.0);
    }

    function getTitulo() {
        const titulos = [
            { min: 1, titulo: '🌱 Iniciante' },
            { min: 5, titulo: '🌿 Aprendiz' },
            { min: 10, titulo: '⚔️ Guerreiro' },
            { min: 20, titulo: '🛡️ Mestre' },
            { min: 35, titulo: '🏆 Lendário' },
            { min: 50, titulo: '👑 Herói' },
            { min: 75, titulo: '⚡ Deus da Guerra' },
            { min: 100, titulo: '🌟 Imortal' }
        ];
        let t = titulos[0].titulo;
        for (const item of titulos) {
            if (levelState.nivel >= item.min) t = item.titulo;
        }
        return t;
    }

    // ============================================================
    // LOG DE ATIVIDADES
    // ============================================================
    function addLog(mensagem, tipo = 'info') {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        
        levelState.atividades.unshift({
            time: timeStr,
            msg: mensagem,
            type: tipo,
            timestamp: now.getTime()
        });

        if (levelState.atividades.length > 50) {
            levelState.atividades = levelState.atividades.slice(0, 50);
        }

        renderLog();
        salvarLog(mensagem, tipo);
    }

    function renderLog() {
        if (levelState.atividades.length === 0) {
            logList.innerHTML = `
                <div class="log-entry">
                    <span class="log-time">--</span>
                    <span class="log-msg" style="color:#6a7a8a;">Aguardando atividades...</span>
                </div>
            `;
            return;
        }

        logList.innerHTML = levelState.atividades.map(log => `
            <div class="log-entry">
                <span class="log-time">${log.time}</span>
                <span class="log-msg">${log.msg}</span>
                <span class="log-badge">${log.type.toUpperCase()}</span>
            </div>
        `).join('');
    }

    // ============================================================
    // SALVAR LOG NO SUPABASE (TABELA "Atividades")
    // ============================================================
    async function salvarLog(mensagem, tipo) {
        if (!levelState.usuarioLogado || !levelState.supabaseOnline) return;

        try {
            const { error } = await supabase
                .from('Atividades')
                .insert({
                    login: levelState.usuarioLogado.login,
                    mensagem: mensagem,
                    tipo: tipo,
                    nivel: levelState.nivel,
                    exp: levelState.exp,
                    created_at: new Date().toISOString()
                });

            if (error) {
                console.warn('⚠️ Erro ao salvar log:', error);
            }
        } catch (e) {
            console.warn('⚠️ Erro ao salvar log:', e);
        }
    }

    // ============================================================
    // CARREGAR LOGS DO SUPABASE
    // ============================================================
    async function carregarLogs(login) {
        if (!login || !levelState.supabaseOnline) return;

        try {
            const { data, error } = await supabase
                .from('Atividades')
                .select('*')
                .eq('login', login)
                .order('created_at', { ascending: false })
                .limit(30);

            if (error) throw error;

            if (data && data.length > 0) {
                levelState.atividades = data.map(item => ({
                    time: new Date(item.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
                    msg: item.mensagem,
                    type: item.tipo || 'info',
                    timestamp: new Date(item.created_at).getTime()
                }));
                renderLog();
            }
        } catch (e) {
            console.warn('⚠️ Erro ao carregar logs:', e);
        }
    }

    // ============================================================
    // UI DO NÍVEL
    // ============================================================
    function atualizarLevelUI() {
        const expProx = getExpProx();
        const pct = Math.min((levelState.exp / expProx) * 100, 100);

        document.getElementById('lwNivel').textContent = levelState.nivel;
        document.getElementById('lwTitulo').textContent = getTitulo();
        
        const fill = document.getElementById('lwExpFill');
        fill.style.width = pct + '%';
        fill.className = 'lw-fill' + (pct > 75 ? ' high' : '');
        
        document.getElementById('lwExpAtual').textContent = levelState.exp;
        document.getElementById('lwExpProx').textContent = expProx;
        document.getElementById('lwHp').textContent = `${levelState.hp}/${getHpMax()}`;
        document.getElementById('lwMp').textContent = `${levelState.mp}/${getMpMax()}`;
        
        const smElement = document.getElementById('lwSm');
        smElement.textContent = `${levelState.sm}/${getSmMax()}`;
        if (levelState.sm < 20) {
            smElement.className = 'sm-c stamina-low';
        } else {
            smElement.className = 'sm-c';
        }
        
        document.getElementById('lwAtk').textContent = getAtk();
        document.getElementById('lwDef').textContent = getDef();
        document.getElementById('lwMag').textContent = getMag();
    }

    function mostrarToast(msg, tipo = 'info') {
        const toast = document.getElementById('levelToast');
        const cores = { sucesso: '#10b981', erro: '#ef4444', info: '#3b82f6', aviso: '#f59e0b' };
        toast.textContent = msg;
        toast.style.borderLeftColor = cores[tipo] || '#3b82f6';
        toast.style.display = 'block';
        toast.style.opacity = '1';
        toast.style.cssText = `
            position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
            background: rgba(10,11,16,0.95); backdrop-filter: blur(8px);
            color: #fff; padding: 10px 22px; border-radius: 12px;
            font-weight: 600; font-size: 0.85rem; box-shadow: 0 8px 32px rgba(0,0,0,0.5);
            border-left: 4px solid ${cores[tipo] || '#3b82f6'};
            z-index: 9999; display: block; opacity: 1;
            transition: opacity 0.4s ease; max-width: 90%; text-align: center;
            font-family: 'Rajdhani', sans-serif;
        `;

        clearTimeout(toast._timer);
        toast._timer = setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => { toast.style.display = 'none'; }, 400);
        }, 3000);
    }

    // ============================================================
    // FUNÇÃO PARA GASTAR STAMINA AO CLICAR NOS JOGOS
    // Com overlay de carregamento e redirecionamento após salvar
    // ============================================================
    function gastarStaminaParaJogar(event) {
        event.preventDefault();
        
        const link = event.currentTarget;
        const gameName = link.getAttribute('data-game-name') || link.getAttribute('data-game') || 'Jogo';
        const gameIcon = link.querySelector('.game-icon')?.textContent || '🎮';
        const href = link.getAttribute('href') || '#';

        // Verifica stamina
        const smMax = getSmMax();
        if (levelState.sm < 10) {
            mostrarToast('⚠️ Stamina insuficiente! Descanse primeiro.', 'erro');
            return;
        }

        // ============================================================
        // MOSTRA OVERLAY DE CARREGAMENTO
        // ============================================================
        loadingIcon.textContent = gameIcon;
        loadingTitle.textContent = `Entrando em ${gameName}...`;
        loadingSub.textContent = 'Preparando sua aventura';
        loadingStamina.textContent = `⚡ -10 STAMINA (${levelState.sm} → ${levelState.sm - 10})`;
        loadingProgressFill.style.width = '0%';
        loadingOverlay.classList.add('active');

        // Anima a barra de progresso
        let progress = 0;
        const progressInterval = setInterval(() => {
            progress += Math.random() * 15 + 5;
            if (progress > 95) progress = 95;
            loadingProgressFill.style.width = Math.min(progress, 95) + '%';
            loadingSub.textContent = progress < 30 ? 'Conectando ao servidor...' :
                                      progress < 60 ? 'Carregando dados do jogador...' :
                                      progress < 80 ? 'Preparando a arena...' :
                                      'Quase lá...';
        }, 150);

        // ============================================================
        // GASTA STAMINA E SALVA
        // ============================================================
        const staminaAntes = levelState.sm;
        levelState.sm -= 10;
        atualizarLevelUI();

        const msg = `🎮 Entrou em ${gameName} (-10 SM: ${staminaAntes} → ${levelState.sm})`;
        addLog(msg, 'info');

        // Salva no Supabase
        salvarNivel()
            .then(() => salvarStats())
            .then(() => {
                // Finaliza o progresso
                clearInterval(progressInterval);
                loadingProgressFill.style.width = '100%';
                loadingSub.textContent = '✅ Pronto! Redirecionando...';
                
                // Pequeno delay para o usuário ver o 100%
                setTimeout(() => {
                    window.location.href = href;
                }, 600);
            })
            .catch((error) => {
                console.error('❌ Erro ao salvar:', error);
                clearInterval(progressInterval);
                loadingSub.textContent = '⚠️ Erro ao salvar, mas continuando...';
                setTimeout(() => {
                    window.location.href = href;
                }, 800);
            });
    }

    // ============================================================
    // CONFIGURAR EVENTOS DOS CARDS DE JOGOS
    // ============================================================
    function configurarEventosDosJogos() {
        const gameCards = document.querySelectorAll('.game-card');
        
        gameCards.forEach(card => {
            card.removeEventListener('click', gastarStaminaParaJogar);
            card.addEventListener('click', gastarStaminaParaJogar);
        });
    }

    // ============================================================
    // SALVAR ESTATÍSTICAS NO SUPABASE
    // ============================================================
    async function salvarStats() {
        if (!levelState.usuarioLogado || !levelState.supabaseOnline) return;

        try {
            const login = levelState.usuarioLogado.login;
            const { error } = await supabase
                .from(TABELA)
                .update({
                    total_treinos: levelState.totalTreinos,
                    total_descansos: levelState.totalDescansos,
                    ultima_atividade: levelState.ultimaAtividade,
                    ultimo_reset: levelState.ultimoReset,
                    updated_at: new Date().toISOString()
                })
                .eq('login', login);

            if (error) throw error;
        } catch (e) {
            console.warn('⚠️ Erro ao salvar stats:', e);
        }
    }

    // ============================================================
    // SUPABASE - SALVAR E CARREGAR NÍVEL
    // ============================================================
    async function salvarNivel() {
        if (!levelState.usuarioLogado || !levelState.supabaseOnline) {
            return;
        }

        try {
            const login = levelState.usuarioLogado.login;
            
            const payload = {
                nivel: levelState.nivel,
                experiencia: levelState.exp,
                exp_proximo: getExpProx(),
                hp_max: getHpMax(),
                mp_max: getMpMax(),
                sm_max: getSmMax(),
                ataque_base: levelState.atkBase,
                defesa_base: levelState.defBase,
                magia_base: levelState.magBase,
                hp_atual: levelState.hp,
                mp_atual: levelState.mp,
                sm_atual: levelState.sm,
                total_treinos: levelState.totalTreinos,
                total_descansos: levelState.totalDescansos,
                ultima_atividade: levelState.ultimaAtividade,
                updated_at: new Date().toISOString()
            };

            const { error } = await supabase
                .from(TABELA)
                .update(payload)
                .eq('login', login);

            if (error) throw error;
        } catch (e) {
            console.error('❌ Erro ao salvar nível:', e);
        }
    }

    async function carregarNivel(login) {
        if (!login) return;

        try {
            const { data, error } = await supabase
                .from(TABELA)
                .select('nivel, experiencia, hp_max, mp_max, sm_max, ataque_base, defesa_base, magia_base, hp_atual, mp_atual, sm_atual, total_treinos, total_descansos, ultima_atividade, ultimo_reset')
                .eq('login', login)
                .single();

            if (error) {
                if (error.code === 'PGRST116') {
                    await criarRegistroNivel(login);
                }
                return;
            }

            if (data) {
                levelState.nivel = data.nivel || 1;
                levelState.exp = data.experiencia || 0;
                levelState.hpMax = data.hp_max || 100;
                levelState.mpMax = data.mp_max || 50;
                levelState.smMax = data.sm_max || 100;
                levelState.atkBase = data.ataque_base || 15;
                levelState.defBase = data.defesa_base || 10;
                levelState.magBase = data.magia_base || 8;
                levelState.hp = data.hp_atual || getHpMax();
                levelState.mp = data.mp_atual || getMpMax();
                levelState.sm = data.sm_atual || getSmMax();
                levelState.totalTreinos = data.total_treinos || 0;
                levelState.totalDescansos = data.total_descansos || 0;
                levelState.ultimaAtividade = data.ultima_atividade || null;
                levelState.ultimoReset = data.ultimo_reset || null;
            }

            atualizarLevelUI();
            await carregarLogs(login);

        } catch (e) {
            console.error('❌ Erro ao carregar nível:', e);
        }
    }

    async function criarRegistroNivel(login) {
        try {
            const payload = {
                nivel: 1,
                experiencia: 0,
                exp_proximo: 100,
                hp_max: 100,
                mp_max: 50,
                sm_max: 100,
                ataque_base: 15,
                defesa_base: 10,
                magia_base: 8,
                hp_atual: 100,
                mp_atual: 50,
                sm_atual: 100,
                total_treinos: 0,
                total_descansos: 0
            };

            const { error } = await supabase
                .from(TABELA)
                .update(payload)
                .eq('login', login);

            if (error) throw error;

            levelState.nivel = 1;
            levelState.exp = 0;
            levelState.hp = 100;
            levelState.mp = 50;
            levelState.sm = 100;
            levelState.totalTreinos = 0;
            levelState.totalDescansos = 0;
            atualizarLevelUI();

            addLog('🌱 Registro de nível criado!', 'info');

        } catch (e) {
            console.error('❌ Erro ao criar registro de nível:', e);
        }
    }

    // ============================================================
    // STATUS SUPABASE
    // ============================================================
    async function verificarConexao() {
        const dot = document.getElementById('supabaseDot');
        const status = document.getElementById('supabaseStatus');
        
        try {
            const { error } = await supabase.from(TABELA).select('id').limit(1);
            levelState.supabaseOnline = !error;
            
            if (levelState.supabaseOnline) {
                dot.className = 'dot online';
                status.className = 'value online';
                status.textContent = 'Online';
            } else {
                dot.className = 'dot offline';
                status.className = 'value offline';
                status.textContent = 'Erro';
            }
            return levelState.supabaseOnline;
        } catch {
            levelState.supabaseOnline = false;
            dot.className = 'dot offline';
            status.className = 'value offline';
            status.textContent = 'Falha';
            return false;
        }
    }

    // ============================================================
    // CARREGAR DADOS DO USUÁRIO
    // ============================================================
    async function loadUserData() {
        try {
            const usuarioData = localStorage.getItem('usuario_logado');
            
            if (!usuarioData) {
                setFallbackUser();
                return;
            }

            const usuario = JSON.parse(usuarioData);
            if (!usuario.login) {
                setFallbackUser();
                return;
            }

            levelState.usuarioLogado = usuario;

            const { data: profile, error: profileError } = await supabase
                .from(TABELA)
                .select('*')
                .eq('login', usuario.login)
                .single();

            if (profileError) {
                const nick = usuario.nome || usuario.login;
                userNickEl.textContent = nick;
                userBalanceEl.textContent = 'R$ 0,00';
                userAvatarEl.textContent = nick.charAt(0).toUpperCase();
                headerUserEl.textContent = nick;
                await carregarNivel(usuario.login);
                return;
            }

            if (profile) {
                const nick = profile.nome || profile.login || usuario.login;
                userNickEl.textContent = nick;
                headerUserEl.textContent = nick;

                const balance = profile.saldo !== undefined && profile.saldo !== null ? profile.saldo : 0;
                userBalanceEl.textContent = new Intl.NumberFormat('pt-BR', {
                    style: 'currency',
                    currency: 'BRL'
                }).format(balance);

                userAvatarEl.textContent = nick.charAt(0).toUpperCase();

                await carregarNivel(profile.login);
                addLog(`👋 Bem-vindo, ${nick}!`, 'info');
            } else {
                setFallbackUser();
            }

        } catch (error) {
            console.error('❌ Erro ao carregar perfil:', error);
            setFallbackUser();
        }
    }

    function setFallbackUser() {
        userNickEl.textContent = 'Visitante';
        userBalanceEl.textContent = 'R$ 0,00';
        userAvatarEl.textContent = '👤';
        headerUserEl.textContent = 'Visitante';
    }

    // ============================================================
    // SALVAR AUTOMATICAMENTE EM INTERVALOS
    // ============================================================
    let saveInterval = null;

    function iniciarSalvamentoAutomatico() {
        saveInterval = setInterval(async () => {
            if (levelState.usuarioLogado && levelState.supabaseOnline) {
                await salvarNivel();
            }
        }, 15000);
    }

    // ============================================================
    // EVENTOS
    // ============================================================
    document.getElementById('btnSair').addEventListener('click', function() {
        if (confirm('Tem certeza que deseja sair?')) {
            salvarNivel();
            localStorage.removeItem('usuario_logado');
            window.location.href = 'login.html';
        }
    });

    document.getElementById('btnReconnectSupabase').addEventListener('click', function() {
        verificarConexao();
        mostrarToast('🔄 Verificando conexão...', 'info');
    });

    // ============================================================
    // INICIALIZAÇÃO
    // ============================================================
    document.addEventListener('DOMContentLoaded', function() {
        console.log('🚀 Dashboard carregado!');

        verificarConexao();
        
        setTimeout(() => {
            loadUserData();
            setTimeout(() => {
                configurarEventosDosJogos();
            }, 500);
        }, 300);

        iniciarSalvamentoAutomatico();

        window.addEventListener('beforeunload', () => {
            if (levelState.usuarioLogado && levelState.supabaseOnline) {
                salvarNivel();
            }
            if (saveInterval) {
                clearInterval(saveInterval);
            }
        });
    });

    // ============================================================
    // EXPOR PARA USO GLOBAL
    // ============================================================
    window.levelSystem = {
        state: levelState,
        salvar: salvarNivel,
        carregar: carregarNivel,
        atualizarUI: atualizarLevelUI,
        addLog,
        getHpMax,
        getMpMax,
        getSmMax,
        getAtk,
        getDef,
        getMag,
        getTitulo,
        getExpProx,
        salvarStats,
        gastarStaminaParaJogar,
        configurarEventosDosJogos
    };

    console.log('📊 Sistema de Nível integrado ao Dashboard!');
    console.log('💾 Salvamento automático a cada 15 segundos');
    console.log('⚡ Cada jogo gasta 10 de STAMINA com overlay!');

})();